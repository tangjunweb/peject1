<template functional>
  <div class="lhyj-ui-button text-elips">
    <slot></slot>
  </div>
</template>
<style lang="less">
.lhyj-ui-button {
  width: 140px;
  height: 40px;
  background: #F54336;
  opacity: 0.8;
  border-radius: 4px;
  cursor: pointer;
  color: #fff;
  font-size: 14px;
  text-align: center;
  line-height: 40px;
}
</style>
