import './aliyun/aliyun-oss-sdk-5.2.0.min'
import './aliyun/aliyun-upload-sdk-1.4.0.min'
export default AliyunUpload.Vod;